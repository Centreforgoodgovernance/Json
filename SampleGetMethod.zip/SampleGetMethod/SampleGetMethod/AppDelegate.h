//
//  AppDelegate.h
//  SampleGetMethod
//
//  Created by Naresh on 5/10/16.
//  Copyright © 2016 Symbioun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

