//
//  ViewController.m
//  SampleGetMethod
//
//  Created by Naresh on 5/10/16.
//  Copyright © 2016 Symbioun.com. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperationManager.h"


@interface ViewController ()

{
    NSArray *nameData;
    
}

@end

@implementation ViewController
@synthesize dataArray,myTableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    nameData=[[NSArray alloc]init];
    
    
    
    [self getDataFromService];
    
    self.myTableView.delegate=(id)self;
    self.myTableView.dataSource=(id)self;
   // [self.myTableView setEditing:YES animated:YES];

    
    }



-(void)getDataFromService
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingAllowFragments];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://testbench.ajrinfo.net/all" parameters:@{@"":@""} success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSLog(@"Response Data :%@",responseObject);

         dataArray = responseObject;
         NSLog(@"Get Array Data from service : %@",dataArray);
         
         _searchArray=dataArray;
         NSLog(@"Searchndta: %@", _searchArray);

         
         nameData=[dataArray valueForKey:@"name"];
         
         NSLog(@"Name Array Data from service : %@",nameData);

         
         self.myTableView.delegate=self;
         self.myTableView.dataSource=self;
         
         [myTableView reloadData];
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
         NSLog(@"%@",error);
     }];
    

}
//https://maps.googleapis.com/maps/api/place/textsearch/json?query=hyderabad%@%20restaurant&sensor=true&key=AIzaSyDGtqi1Teh702nuPJNqFojU_Q5vHwBxBcY



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _searchArray.count;//sample need to chenge here
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellIdentifier=@"cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    cell.textLabel.text=[_searchArray objectAtIndex:indexPath.row][@"name"];
    cell.detailTextLabel.text=[_searchArray objectAtIndex:indexPath.row][@"salary"];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    [self.mSearchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    [self.mSearchBar setShowsCancelButton:NO animated:YES];
    searchBar.text=@"";
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length>0) {
        searchText = [searchText stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSLog(@"its pincode");
        NSPredicate *predicate =
        [NSPredicate predicateWithFormat: @"name CONTAINS[cd] %@ OR salary CONTAINS[cd] %@", searchText, searchText];
        _searchArray= [dataArray filteredArrayUsingPredicate:predicate];
        [myTableView reloadData];
    }
    else
    {
        _searchArray=dataArray;
        [myTableView reloadData];
    }
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.mSearchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [self.mSearchBar resignFirstResponder];
    _searchArray=dataArray;
    [self.myTableView reloadData];
}
//- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return UITableViewCellEditingStyleNone;
//}
//
//- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return YES;
//}
//
//- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
//{
//    [dataArray exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row];
//    [self.myTableView reloadData];
//}




// <<---- POST METHOD  ----- >>>
/*
 - (BOOL)doesAllFieldsEntered
 {
 BOOL isFilled = YES;
 
 if(![self.txt_Name.text length])
 {
 isFilled = NO;
 [self showAlertWithMsg:@"Please Enter your Name"];
 }
 else if(![self.txt_Pwd.text length])
 {
 isFilled = NO;
 [self showAlertWithMsg:@"Please Enter Password"];
 }
 else if(![self.txt_Email.text length])
 {
 isFilled = NO;
 [self showAlertWithMsg:@"Please Enter Email"];
 }
 else if(![self.txt_CntryCode.text length])
 {
 isFilled = NO;
 [self showAlertWithMsg:@"Please Enter City"];
 }
 else if(![self.txt_Mobile.text length])
 {
 isFilled = NO;
 [self showAlertWithMsg:@"Please Enter Mobile No"];
 }
 
 if(isFilled)
 {
 isFilled = [self isValidEmailId:self.txt_Email.text];
 
 if(!isFilled)
 [self showAlertWithMsg:@"Please enter valid email id"];
 }
 
 return isFilled;
 }
 
 - (BOOL)isValidEmailId:(NSString *)aStrEmail
 {
 NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
 NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
 
 return [emailTest evaluateWithObject:aStrEmail];
 }
 
 - (void)showAlertWithMsg:(NSString *)strMsg
 {
 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
 message:strMsg
 delegate:nil
 cancelButtonTitle:@"Ok"
 otherButtonTitles:nil];
 [alert show];
 }
 
 - (IBAction)signupBtnClicked:(id)sender {
 
 
 BOOL filledAll = [self doesAllFieldsEntered];
 
 if(filledAll)
 {
 
 //    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
 //    [dict setValue:self.txt_Name.text forKey:@"username"];
 //    [dict setValue:self.txt_Email.text forKey:@"email"];
 //    [dict setValue:self.txt_Pwd.text forKey:@"pwd"];
 //    [dict setValue:self.txt_CntryCode.text forKey:@"city"];
 //    [dict setValue:self.txt_Mobile.text forKey:@"phnum"];
 
 
 AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
 manager.responseSerializer = [AFJSONResponseSerializer serializer];
 manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/plain"];
 
 NSString *city=@"1";
 
 [manager GET:@"http://183.82.114.64/zaaek/mobile/registerUser?" parameters:@{@"username":txt_Name.text, @"pwd":txt_Pwd.text,@"phnum":txt_Mobile.text,@"email":txt_Email.text,@"city":city} success:^(AFHTTPRequestOperation *operation, id responseObject)
 {
 NSLog(@"Response -- %@",responseObject);
 
 txt_Name.text = @"";
 txt_Pwd.text= @"";
 txt_Email.text = @"";
 txt_Mobile.text= @"";
 txt_CntryCode.text = @"";
 
 
 } failure:^(AFHTTPRequestOperation *operation, NSError *error)
 {
 
 NSLog(@"Somthing Went Wrong : %@",error);
 }];
 }
 */
@end
