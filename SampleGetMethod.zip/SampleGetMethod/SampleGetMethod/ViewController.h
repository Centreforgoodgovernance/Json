//
//  ViewController.h
//  SampleGetMethod
//
//  Created by Naresh on 5/10/16.
//  Copyright © 2016 Symbioun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (weak, nonatomic) IBOutlet UISearchBar *mSearchBar;
@property(nonatomic,strong)NSArray *searchArray;
@property(nonatomic,strong)NSMutableArray *dataArray;

@end

